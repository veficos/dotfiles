#!/bin/bash 

bin/unix/ctags -I __THROW --file-scope=yes --langmap=c:+.h --languages=c,c++ --links=yes --c-kinds=+p --fields=+S  -R -f systags /usr/include /usr/local/include

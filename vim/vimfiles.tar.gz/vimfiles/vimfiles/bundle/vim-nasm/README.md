# vim-nasm

File detection and a filetype plugin for [NASM](http://www.nasm.us/).
The filetype plugin is based on irock's filetype plugin which can be found at
https://github.com/irock/vim-config/blob/master/vim/ftplugin/nasm.vim.
